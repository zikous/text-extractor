// Real OCR Processing Library using Tesseract.js
import Tesseract, { createWorker } from "tesseract.js"

export interface ExtractedLine {
  id: string
  filename: string
  text: string
  confidence: number
}

// Tesseract.js worker instance for better performance
let worker: Tesseract.Worker | null = null

// Initialize Tesseract worker
async function initializeWorker(): Promise<Tesseract.Worker> {
  if (!worker) {
    console.log("Initializing Tesseract worker...")
    worker = await createWorker("eng")
    console.log("Tesseract worker initialized successfully")

    // Configure Tesseract for better accuracy
    await worker.setParameters({
      tessedit_pageseg_mode: Tesseract.PSM.AUTO,
    })
    console.log("Tesseract parameters configured")
  }
  return worker
}

// Clean up worker when done
export async function terminateWorker(): Promise<void> {
  if (worker) {
    await worker.terminate()
    worker = null
    console.log("Tesseract worker terminated")
  }
}

// Split text into lines based on line breaks
function createLinesFromText(text: string): Array<{ text: string; confidence: number }> {
  const lines = text.split("\n").filter((line) => line.trim().length > 0)
  return lines.map((line) => ({
    text: line,
    confidence: 90, // Default confidence for text-based lines
  }))
}

// Main Tesseract.js OCR processing function
export async function processImageWithTesseract(
  filename: string,
  base64Image: string,
  onProgress?: (progress: number) => void,
): Promise<ExtractedLine[]> {
  console.log(`Starting OCR processing for ${filename}`)

  try {
    // Validate input
    if (!base64Image || !base64Image.startsWith("data:image/")) {
      throw new Error("Invalid image data provided")
    }

    // Initialize worker
    const tesseractWorker = await initializeWorker()

    // Simulate initial progress
    if (onProgress) {
      onProgress(0.1)
    }

    console.log("Starting Tesseract recognition...")

    // Process image with Tesseract
    const result = await tesseractWorker.recognize(base64Image)

    console.log("Tesseract recognition completed")

    // Simulate progress updates
    if (onProgress) {
      onProgress(0.7)
    }

    // Check if result and data exist
    if (!result || !result.data) {
      console.warn(`No OCR data returned for ${filename}`)
      return []
    }

    const { data } = result
    console.log("OCR Data structure:", {
      hasLines: !!data.lines,
      linesLength: data.lines?.length,
      hasWords: !!data.words,
      wordsLength: data.words?.length,
      hasText: !!data.text,
      text: data.text?.substring(0, 100) + "...",
    })

    // Determine which data to use for line extraction
    let textElements: Array<{ text: string; confidence: number }> = []

    // First try to use lines from Tesseract
    if (data.lines && Array.isArray(data.lines) && data.lines.length > 0) {
      console.log(`Using ${data.lines.length} lines from Tesseract`)
      textElements = data.lines
        .filter((line) => line && line.text && line.text.trim().length > 0)
        .map((line) => ({
          text: line.text.trim(),
          confidence: line.confidence || 80,
        }))
    }
    // If no lines, try to use paragraphs
    else if (data.paragraphs && Array.isArray(data.paragraphs) && data.paragraphs.length > 0) {
      console.log(`Using ${data.paragraphs.length} paragraphs from Tesseract`)
      textElements = data.paragraphs
        .filter((para) => para && para.text && para.text.trim().length > 0)
        .map((para) => ({
          text: para.text.trim(),
          confidence: para.confidence || 80,
        }))
    }
    // If no structured data but we have text, create artificial lines
    else if (data.text && data.text.trim().length > 0) {
      console.log(`Creating lines from raw text (${data.text.split("\n").length} lines)`)
      textElements = createLinesFromText(data.text)
    }
    // Last resort: use words and group them
    else if (data.words && Array.isArray(data.words) && data.words.length > 0) {
      console.log(`Using ${data.words.length} words from Tesseract`)

      // Group words by approximate y-coordinate to form lines
      const wordsByLine: Record<number, typeof data.words> = {}
      const lineThreshold = 10 // pixels tolerance for same line

      data.words.forEach((word) => {
        if (!word || !word.text || !word.bbox) return

        const yCenter = (word.bbox.y0 + word.bbox.y1) / 2
        const lineKey = Math.floor(yCenter / lineThreshold) * lineThreshold

        if (!wordsByLine[lineKey]) {
          wordsByLine[lineKey] = []
        }

        wordsByLine[lineKey].push(word)
      })

      // Convert grouped words to lines
      Object.entries(wordsByLine).forEach(([_, words]) => {
        // Sort words by x-coordinate
        words.sort((a, b) => a.bbox.x0 - b.bbox.x0)

        // Combine words into a line
        const text = words.map((w) => w.text).join(" ")
        const confidence = words.reduce((sum, w) => sum + w.confidence, 0) / words.length

        textElements.push({ text, confidence })
      })
    }

    // If we still have no elements, return empty result
    if (textElements.length === 0) {
      console.warn(`No valid text elements found in ${filename}`)
      return []
    }

    console.log(`Found ${textElements.length} text elements to process`)

    // Lower the confidence threshold to get more results
    const validElements = textElements.filter((element) => {
      // Default confidence if not provided
      if (element.confidence === undefined) {
        element.confidence = 80
      }
      return element.confidence > 10 // Very low threshold to get more results
    })

    // Simulate more progress
    if (onProgress) {
      onProgress(0.9)
    }

    // Convert Tesseract elements to our format
    const extractedLines: ExtractedLine[] = validElements.map((element, index) => {
      const line = {
        id: `${filename}-${Date.now()}-${index}`,
        filename,
        text: element.text.trim(),
        confidence: Math.round(element.confidence),
      }

      console.log(`Created line ${index + 1}:`, {
        text: line.text.substring(0, 50) + (line.text.length > 50 ? "..." : ""),
        confidence: line.confidence,
      })

      return line
    })

    // Final progress update
    if (onProgress) {
      onProgress(1.0)
    }

    console.log(`Successfully processed ${filename}: ${extractedLines.length} text elements extracted`)
    return extractedLines
  } catch (error) {
    console.error(`Error processing ${filename} with Tesseract:`, error)
    throw new Error(`Failed to process ${filename}: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}
