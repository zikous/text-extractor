export const exportToCSV = (data: any[], filename = "extracted_text") => {
  if (!data || data.length === 0) {
    console.warn("No data to export to CSV")
    return
  }

  let csvContent = ""

  if (data.length > 0 && Object.keys(data[0]).length === 1 && data[0].text !== undefined) {
    csvContent = "Extracted Text\n"
    data.forEach((item) => {
      let text = item.text || ""
      if (text.includes('"')) {
        text = text.replace(/"/g, '""')
      }
      if (text.includes(",") || text.includes("\n") || text.includes('"')) {
        text = `"${text}"`
      }
      csvContent += text + "\n"
    })
  } else {
    const headers = Object.keys(data[0])
    csvContent = headers.join(",") + "\n"

    data.forEach((row) => {
      const values = headers.map((header) => {
        let value = row[header] || ""
        if (typeof value === "string") {
          if (value.includes('"')) {
            value = value.replace(/"/g, '""')
          }
          if (value.includes(",") || value.includes("\n") || value.includes('"')) {
            value = `"${value}"`
          }
        }
        return value
      })
      csvContent += values.join(",") + "\n"
    })
  }

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  downloadFile(blob, `${filename}.csv`)
}

export const exportToExcel = (data: any[], filename = "extracted_text") => {
  if (!data || data.length === 0) {
    console.warn("No data to export to Excel")
    return
  }

  // Create Excel-compatible XML
  let xml = `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>OCR Extractor</Author>
  <Created>${new Date().toISOString()}</Created>
 </DocumentProperties>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>12000</WindowHeight>
  <WindowWidth>16000</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s62">
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000" ss:Bold="1"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="Sheet1">
  <Table>`

  if (data.length > 0 && Object.keys(data[0]).length === 1 && data[0].text !== undefined) {
    // Single column data
    xml += `<Row><Cell ss:StyleID="s62"><Data ss:Type="String">Extracted Text</Data></Cell></Row>`
    data.forEach((item) => {
      const text = escapeXml(item.text || "")
      xml += `<Row><Cell><Data ss:Type="String">${text}</Data></Cell></Row>`
    })
  } else {
    // Multi-column data
    const headers = Object.keys(data[0])
    xml += `<Row>`
    headers.forEach((header) => {
      xml += `<Cell ss:StyleID="s62"><Data ss:Type="String">${escapeXml(header)}</Data></Cell>`
    })
    xml += `</Row>`

    data.forEach((row) => {
      xml += `<Row>`
      headers.forEach((header) => {
        const value = escapeXml((row[header] || "").toString())
        xml += `<Cell><Data ss:Type="String">${value}</Data></Cell>`
      })
      xml += `</Row>`
    })
  }

  xml += `</Table>
 </Worksheet>
</Workbook>`

  const blob = new Blob([xml], {
    type: "application/vnd.ms-excel;charset=utf-8;",
  })

  downloadFile(blob, `${filename}.xls`)
}

// Helper function to download file
const downloadFile = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

// Escape XML special characters
const escapeXml = (text: string) => {
  if (typeof text !== "string") return text
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}
