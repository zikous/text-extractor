"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { X, ZoomIn, ZoomOut, RotateCw, Download } from "lucide-react"

interface ImageViewerModalProps {
  isOpen: boolean
  onClose: () => void
  imageSrc: string
  imageTitle: string
  imageSize?: number
}

export function ImageViewerModal({ isOpen, onClose, imageSrc, imageTitle, imageSize }: ImageViewerModalProps) {
  const [zoom, setZoom] = useState(1)
  const [rotation, setRotation] = useState(0)

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.25, 3))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.25, 0.25))
  }

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360)
  }

  const handleDownload = () => {
    const link = document.createElement("a")
    link.href = imageSrc
    link.download = imageTitle
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const resetView = () => {
    setZoom(1)
    setRotation(0)
  }

  // Reset view when modal opens
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
      resetView()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="p-4 pb-2">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-lg font-semibold">{imageTitle}</DialogTitle>
              {imageSize && <p className="text-sm text-gray-500 mt-1">Size: {Math.round(imageSize / 1024)}KB</p>}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleZoomOut} disabled={zoom <= 0.25}>
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium min-w-[60px] text-center">{Math.round(zoom * 100)}%</span>
              <Button variant="outline" size="sm" onClick={handleZoomIn} disabled={zoom >= 3}>
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleRotate}>
                <RotateCw className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-auto p-4 pt-2">
          <div className="flex items-center justify-center min-h-[400px]">
            <div
              className="transition-transform duration-200 ease-in-out"
              style={{
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
                transformOrigin: "center",
              }}
            >
              <img
                src={imageSrc || "/placeholder.svg"}
                alt={imageTitle}
                className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                style={{ maxHeight: "60vh" }}
              />
            </div>
          </div>
        </div>

        <div className="p-4 pt-2 border-t bg-gray-50">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center gap-4">
              <span>Use mouse wheel to zoom</span>
              <span>•</span>
              <Button variant="link" size="sm" onClick={resetView} className="h-auto p-0 text-sm">
                Reset view
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <span>Zoom: {Math.round(zoom * 100)}%</span>
              <span>•</span>
              <span>Rotation: {rotation}°</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
