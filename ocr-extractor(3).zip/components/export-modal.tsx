"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FileText, Table, Download } from "lucide-react"

interface ExportModalProps {
  isOpen: boolean
  onClose: () => void
  onExport: (filename: string, format: "csv" | "excel") => void
  defaultFilename: string
}

export function ExportModal({ isOpen, onClose, onExport, defaultFilename }: ExportModalProps) {
  const [filename, setFilename] = useState(defaultFilename)
  const [format, setFormat] = useState<"csv" | "excel">("csv")

  const handleExport = () => {
    const cleanFilename = filename.trim() || defaultFilename
    onExport(cleanFilename, format)
    onClose()
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
      setFilename(defaultFilename)
      setFormat("csv")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Data
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="filename">File Name</Label>
            <Input
              id="filename"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="Enter filename..."
              className="w-full"
            />
          </div>

          <div className="space-y-3">
            <Label>Export Format</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant={format === "csv" ? "default" : "outline"}
                onClick={() => setFormat("csv")}
                className="flex items-center gap-2 h-12"
              >
                <FileText className="h-4 w-4" />
                <div className="text-left">
                  <div className="font-medium">CSV</div>
                  <div className="text-xs opacity-70">Comma separated</div>
                </div>
              </Button>
              <Button
                variant={format === "excel" ? "default" : "outline"}
                onClick={() => setFormat("excel")}
                className="flex items-center gap-2 h-12"
              >
                <Table className="h-4 w-4" />
                <div className="text-left">
                  <div className="font-medium">Excel</div>
                  <div className="text-xs opacity-70">Spreadsheet (.xls)</div>
                </div>
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleExport} disabled={!filename.trim()}>
            <Download className="h-4 w-4 mr-2" />
            Export {format.toUpperCase()}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
