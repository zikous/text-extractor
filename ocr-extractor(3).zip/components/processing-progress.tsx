"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Clock, Loader2 } from "lucide-react"

interface ProcessingProgressProps {
  currentFile: string
  fileIndex: number
  totalFiles: number
  ocrProgress: number
  isComplete: boolean
}

export function ProcessingProgress({
  currentFile,
  fileIndex,
  totalFiles,
  ocrProgress,
  isComplete,
}: ProcessingProgressProps) {
  const overallProgress = totalFiles > 0 ? ((fileIndex + ocrProgress / 100) / totalFiles) * 100 : 0

  return (
    <Card className="mt-4">
      <CardContent className="pt-6">
        <div className="space-y-4">
          {/* Overall Progress Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isComplete ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />
              )}
              <span className="font-medium">
                {isComplete ? "Processing Complete" : "Processing Images with Tesseract.js"}
              </span>
            </div>
            <span className="text-sm text-gray-600">
              {Math.min(fileIndex + (isComplete ? 1 : 0), totalFiles)} / {totalFiles}
            </span>
          </div>

          {/* Overall Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Overall Progress</span>
              <span className="font-medium">{Math.round(overallProgress)}%</span>
            </div>
            <Progress value={overallProgress} className="w-full" />
          </div>

          {/* Current File Progress */}
          {!isComplete && currentFile && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">
                  Current: <span className="font-medium">{currentFile}</span>
                </span>
                <span className="font-medium">{Math.round(ocrProgress * 100)}%</span>
              </div>
              <Progress value={ocrProgress * 100} className="w-full h-2" />
            </div>
          )}

          {/* Status Messages */}
          <div className="text-sm text-gray-600">
            {isComplete ? (
              <div className="flex items-center gap-2 text-green-700">
                <CheckCircle className="h-4 w-4" />
                <span>All images processed successfully!</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>
                  {ocrProgress > 0
                    ? `Extracting text from ${currentFile}...`
                    : `Preparing to process ${currentFile}...`}
                </span>
              </div>
            )}
          </div>

          {/* Processing Tips */}
          {!isComplete && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="text-sm text-blue-800">
                <strong>Tip:</strong> For better OCR results, use high-resolution images with clear, well-lit text.
                Processing time varies based on image size and complexity.
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
