"use client"

import type React from "react"

import { useState, useCallback } from "react"
import {
  Upload,
  Plus,
  Trash2,
  FileText,
  AlertCircle,
  ImageIcon,
  Scissors,
  Undo,
  SplitSquareHorizontal,
  Download,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Table as UITable, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { processImageWithTesseract, type ExtractedLine } from "@/lib/ocr"
import { exportToCSV, exportToExcel } from "@/lib/export-utils"
import { ProcessingProgress } from "@/components/processing-progress"
import { ImageViewerModal } from "@/components/image-viewer-modal"
import { ExportModal } from "@/components/export-modal"

interface UploadedImage {
  id: string
  filename: string
  base64: string
  size: number
}

interface ExtractedLineWithDepartment extends ExtractedLine {
  department?: string
  originalText?: string
  isSplit?: boolean
}

export default function OCRExtractor() {
  const [extractedLines, setExtractedLines] = useState<ExtractedLineWithDepartment[]>([])
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [error, setError] = useState<string | null>(null)
  const [departmentMode, setDepartmentMode] = useState(false)
  const [exportModal, setExportModal] = useState(false)
  const [imageViewerModal, setImageViewerModal] = useState({
    isOpen: false,
    imageSrc: "",
    imageTitle: "",
    imageSize: 0,
  })
  const [processingProgress, setProcessingProgress] = useState({
    currentFile: "",
    fileIndex: 0,
    ocrProgress: 0,
    isComplete: false,
  })
  const { toast } = useToast()

  const openImageViewer = (imageSrc: string, imageTitle: string, imageSize?: number) => {
    setImageViewerModal({ isOpen: true, imageSrc, imageTitle, imageSize: imageSize || 0 })
  }

  const closeImageViewer = () => {
    setImageViewerModal({ isOpen: false, imageSrc: "", imageTitle: "", imageSize: 0 })
  }

  const handleFileUpload = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return

      const fileArray = Array.from(files)
      setSelectedFiles(fileArray)
      setIsProcessing(true)
      setError(null)
      setProcessingProgress({ currentFile: "", fileIndex: 0, ocrProgress: 0, isComplete: false })

      try {
        const allExtractedLines: ExtractedLineWithDepartment[] = []
        const newUploadedImages: UploadedImage[] = []

        for (let i = 0; i < fileArray.length; i++) {
          const file = fileArray[i]

          setProcessingProgress((prev) => ({
            ...prev,
            currentFile: file.name,
            fileIndex: i,
            ocrProgress: 0,
          }))

          if (!file.type.startsWith("image/")) {
            setError(`Invalid file type: ${file.name}. Please upload image files only.`)
            continue
          }

          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader()
            reader.onload = (e) => resolve(e.target?.result as string)
            reader.onerror = reject
            reader.readAsDataURL(file)
          })

          newUploadedImages.push({
            id: `img-${Date.now()}-${i}`,
            filename: file.name,
            base64,
            size: file.size,
          })

          const lines = await processImageWithTesseract(file.name, base64, (progress) => {
            setProcessingProgress((prev) => ({ ...prev, ocrProgress: progress }))
          })

          allExtractedLines.push(
            ...lines.map((line) => ({
              ...line,
              department: "",
              originalText: line.text,
              isSplit: false,
            })),
          )
        }

        setProcessingProgress((prev) => ({ ...prev, isComplete: true }))
        setExtractedLines((prev) => [...allExtractedLines, ...prev])
        setUploadedImages((prev) => [...newUploadedImages, ...prev])

        toast({
          title: "OCR Processing Complete",
          description: `Extracted ${allExtractedLines.length} text lines from ${fileArray.length} image(s)`,
        })
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error occurred"
        setError(`OCR Processing Error: ${errorMessage}`)
        toast({
          title: "OCR Processing Error",
          description: errorMessage,
          variant: "destructive",
        })
      } finally {
        setIsProcessing(false)
        setTimeout(() => {
          setProcessingProgress({ currentFile: "", fileIndex: 0, ocrProgress: 0, isComplete: false })
        }, 3000)
      }
    },
    [toast],
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      handleFileUpload(e.dataTransfer.files)
    },
    [handleFileUpload],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
  }, [])

  const addNewRow = () => {
    const newLine: ExtractedLineWithDepartment = {
      id: `manual-${Date.now()}`,
      filename: "manual_entry.jpg",
      text: "",
      confidence: 0,
      department: "",
      originalText: "",
      isSplit: false,
    }
    setExtractedLines((prev) => [newLine, ...prev])
  }

  const deleteRow = (id: string) => {
    setExtractedLines((prev) => prev.filter((line) => line.id !== id))
  }

  const updateLineText = (id: string, newText: string) => {
    setExtractedLines((prev) =>
      prev.map((line) =>
        line.id === id
          ? {
              ...line,
              text: newText,
              originalText: line.isSplit ? line.originalText : newText,
            }
          : line,
      ),
    )
  }

  const updateLineDepartment = (id: string, newDepartment: string) => {
    setExtractedLines((prev) => prev.map((line) => (line.id === id ? { ...line, department: newDepartment } : line)))
  }

  const splitLine = (id: string) => {
    const line = extractedLines.find((l) => l.id === id)
    if (!line || line.isSplit) return

    const words = line.text.trim().split(/\s+/)
    if (words.length < 2) {
      toast({
        title: "Cannot Split",
        description: "Line must have at least 2 words to split",
        variant: "destructive",
      })
      return
    }

    const lastWord = words[words.length - 1]
    const remainingText = words.slice(0, -1).join(" ")

    setExtractedLines((prev) =>
      prev.map((l) =>
        l.id === id
          ? {
              ...l,
              text: remainingText,
              department: lastWord,
              isSplit: true,
              originalText: l.originalText || l.text,
            }
          : l,
      ),
    )

    toast({
      title: "Line Split",
      description: `Moved "${lastWord}" to department column`,
    })
  }

  const undoSplit = (id: string) => {
    const line = extractedLines.find((l) => l.id === id)
    if (!line || !line.isSplit || !line.originalText) return

    setExtractedLines((prev) =>
      prev.map((l) =>
        l.id === id
          ? {
              ...l,
              text: l.originalText || l.text,
              department: "",
              isSplit: false,
            }
          : l,
      ),
    )

    toast({
      title: "Split Undone",
      description: "Restored original text",
    })
  }

  const splitAllLines = () => {
    let splitCount = 0

    setExtractedLines((prev) =>
      prev.map((line) => {
        if (line.isSplit) return line

        const words = line.text.trim().split(/\s+/)
        if (words.length < 2) return line

        const lastWord = words[words.length - 1]
        const remainingText = words.slice(0, -1).join(" ")
        splitCount++

        return {
          ...line,
          text: remainingText,
          department: lastWord,
          isSplit: true,
          originalText: line.originalText || line.text,
        }
      }),
    )

    toast({
      title: "Bulk Split Complete",
      description: `Split ${splitCount} lines`,
    })
  }

  const deleteImage = (id: string) => {
    setUploadedImages((prev) => prev.filter((img) => img.id !== id))
  }

  const clearAll = () => {
    setExtractedLines([])
    setUploadedImages([])
    toast({
      title: "Cleared",
      description: "All data and images cleared",
    })
  }

  const handleExport = async (filename: string, format: "csv" | "excel") => {
    try {
      const exportData = departmentMode
        ? extractedLines.map((line) => ({
            text: line.text,
            department: line.department || "",
          }))
        : extractedLines.map((line) => ({ text: line.text }))

      if (format === "csv") {
        exportToCSV(exportData, filename)
        toast({
          title: "Export Complete",
          description: `Data exported as ${filename}.csv`,
        })
      } else {
        exportToExcel(exportData, filename)
        toast({
          title: "Export Complete",
          description: `Data exported as ${filename}.xls`,
        })
      }
    } catch (error) {
      toast({
        title: "Export Error",
        description: "Failed to export file",
        variant: "destructive",
      })
    }
  }

  const getDefaultFilename = () => {
    const timestamp = new Date().toISOString().slice(0, 10)
    return `extracted_text_${timestamp}`
  }

  const splittableLines = extractedLines.filter((line) => !line.isSplit && line.text.trim().split(/\s+/).length >= 2)

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">OCR Text Extractor</h1>
          <p className="text-gray-600">Upload images to extract text using Tesseract.js</p>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="text-base font-medium">Department Mode</Label>
                <p className="text-sm text-gray-600">
                  Enable to add Department column for classification and auto-split functionality
                </p>
              </div>
              <Switch checked={departmentMode} onCheckedChange={setDepartmentMode} />
            </div>
          </CardContent>
        </Card>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload Images
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors cursor-pointer"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onClick={() => document.getElementById("file-input")?.click()}
            >
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-700 mb-2">Drop images here or click to browse</p>
              <p className="text-sm text-gray-500">Supports JPG, PNG, GIF files</p>
              <input
                id="file-input"
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileUpload(e.target.files)}
                disabled={isProcessing}
              />
            </div>

            {selectedFiles.length > 0 && (
              <div className="mt-4">
                <Label className="text-sm font-medium">Selected Files:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedFiles.map((file, index) => (
                    <Badge key={index} variant="secondary">
                      {file.name} ({Math.round(file.size / 1024)}KB)
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {isProcessing && (
              <ProcessingProgress
                currentFile={processingProgress.currentFile}
                fileIndex={processingProgress.fileIndex}
                totalFiles={selectedFiles.length}
                ocrProgress={processingProgress.ocrProgress}
                isComplete={processingProgress.isComplete}
              />
            )}
          </CardContent>
        </Card>

        {uploadedImages.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5" />
                  <span>Uploaded Images</span>
                </div>
                <Badge variant="secondary">{uploadedImages.length} images</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {uploadedImages.map((image) => (
                  <div key={image.id} className="relative group">
                    <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden border">
                      <img
                        src={image.base64 || "/placeholder.svg"}
                        alt={image.filename}
                        className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                        onClick={() => openImageViewer(image.base64, image.filename, image.size)}
                      />
                    </div>
                    <div className="mt-2 space-y-1">
                      <p className="text-sm font-medium text-gray-900 truncate" title={image.filename}>
                        {image.filename}
                      </p>
                      <p className="text-xs text-gray-500">{Math.round(image.size / 1024)}KB</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteImage(image.id)}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 hover:bg-white text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-wrap gap-4 justify-between items-center">
          <div className="flex gap-2">
            <Button onClick={addNewRow} variant="outline" disabled={isProcessing}>
              <Plus className="h-4 w-4 mr-2" />
              Add Row
            </Button>
            {departmentMode && (
              <Button onClick={splitAllLines} variant="outline" disabled={isProcessing || splittableLines.length === 0}>
                <SplitSquareHorizontal className="h-4 w-4 mr-2" />
                Split All ({splittableLines.length})
              </Button>
            )}
            <Button onClick={clearAll} variant="outline" disabled={extractedLines.length === 0 || isProcessing}>
              <Trash2 className="h-4 w-4 mr-2" />
              Clear All
            </Button>
          </div>

          <div className="flex gap-2">
            <Button onClick={() => setExportModal(true)} disabled={extractedLines.length === 0}>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Extracted Text Lines</span>
              <Badge variant="secondary">{extractedLines.length} lines</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {extractedLines.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No text lines extracted yet</p>
                <p className="text-sm">Upload images to get started</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <UITable>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[60px]">Line</TableHead>
                      <TableHead>File</TableHead>
                      <TableHead className="min-w-[300px]">Extracted Text</TableHead>
                      {departmentMode && <TableHead className="w-[150px]">Department</TableHead>}
                      <TableHead className="w-[120px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {extractedLines.map((line, index) => (
                      <TableRow key={line.id}>
                        <TableCell className="font-medium">{index + 1}</TableCell>
                        <TableCell className="text-sm text-gray-600">{line.filename}</TableCell>
                        <TableCell>
                          <Textarea
                            value={line.text}
                            onChange={(e) => updateLineText(line.id, e.target.value)}
                            className="min-h-[60px] resize-none"
                            placeholder="Enter extracted text..."
                          />
                        </TableCell>
                        {departmentMode && (
                          <TableCell>
                            <Input
                              value={line.department || ""}
                              onChange={(e) => updateLineDepartment(line.id, e.target.value)}
                              placeholder="Department..."
                              className="w-full"
                            />
                          </TableCell>
                        )}
                        <TableCell>
                          <div className="flex gap-1">
                            {departmentMode && (
                              <>
                                {line.isSplit ? (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => undoSplit(line.id)}
                                    className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                                    title="Undo split"
                                  >
                                    <Undo className="h-4 w-4" />
                                  </Button>
                                ) : (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => splitLine(line.id)}
                                    disabled={line.text.trim().split(/\s+/).length < 2}
                                    className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 disabled:text-gray-400 disabled:hover:bg-transparent"
                                    title="Split line (last word to department)"
                                  >
                                    <Scissors className="h-4 w-4" />
                                  </Button>
                                )}
                              </>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteRow(line.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </UITable>
              </div>
            )}
          </CardContent>
        </Card>

        <ExportModal
          isOpen={exportModal}
          onClose={() => setExportModal(false)}
          onExport={handleExport}
          defaultFilename={getDefaultFilename()}
        />

        <ImageViewerModal
          isOpen={imageViewerModal.isOpen}
          onClose={closeImageViewer}
          imageSrc={imageViewerModal.imageSrc}
          imageTitle={imageViewerModal.imageTitle}
          imageSize={imageViewerModal.imageSize}
        />

        <div className="text-center text-sm text-gray-500 py-4">
          <p>Powered by Tesseract.js - Real OCR Text Extraction</p>
        </div>
      </div>
    </div>
  )
}
